package com.app.XMLProcessing.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);

}
